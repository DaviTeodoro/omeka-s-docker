# CustomVocab

Create custom vocabularies and add them as data types to your resource templates.

See the [Omeka S user manual](http://omeka.org/s/docs/user-manual/modules/customvocab/) for user documentation.

## Installation

See general end user documentation for [Installing a module](http://omeka.org/s/docs/user-manual/modules/#installing-modules)
