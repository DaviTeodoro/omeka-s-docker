<?php
namespace NumericDataTypes\Form\Element;

class Timestamp extends DateTime
{
}
