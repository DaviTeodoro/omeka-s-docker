<?php
namespace Annotate\Permissions;

class Acl extends \Omeka\Permissions\Acl
{
    const ROLE_ANNOTATOR = 'annotator';
}
